export function GET(){return Response.json({ok:true,service:"donlien.xyz",status:"online"})}
