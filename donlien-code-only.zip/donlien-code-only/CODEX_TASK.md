# Codex task
1. Run npm install and npm run build.
2. Fix all errors.
3. Preserve full-screen room navigation; do not turn this into a long scrolling homepage.
4. Do not enable minting.
5. Before adding persistent accounts, propose database schema, secure image storage, WalletConnect nonce authentication, Mirror Node checks, and privacy-safe HCS audit events.
6. Keep canonical image filenames unchanged.
7. Report Netlify deployment steps.
