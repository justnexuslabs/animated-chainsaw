Place approved images here with these exact names:
- hero-home.png
- mission-control.png
- genesis-vault.png
- lienity-atrium.png
- archive-vault.png
