import Link from "next/link";
import {siteConfig} from "@/config/site";
export function Shell({children}:{children:React.ReactNode}){return <div className="app-shell"><header className="topbar"><Link href="/" className="brand">DONLIEN<span>.XYZ</span></Link><nav className="desktop-nav">{siteConfig.nav.map(i=><Link key={i.href} href={i.href}>{i.label}</Link>)}</nav><Link className="top-cta" href="/become-a-lien">Activate ID</Link></header><main>{children}</main><nav className="mobile-nav">{siteConfig.nav.slice(0,5).map(i=><Link key={i.href} href={i.href}>{i.label}</Link>)}</nav></div>}
