# DonLien.xyz Starter

Netlify-ready Next.js App Router starter.

## Run
```bash
npm install
npm run dev
```

## Deploy
Build command: `npm run build`
Publish directory: `.next`

## Routes
`/`, `/mission-control`, `/genesis`, `/lienity`, `/archive`, `/become-a-lien`

## MVP limits
The LIEN ID is browser-only, photos are not persisted or AI-transformed, X sharing pre-fills text but cannot attach the PNG, and minting is disabled.
